//:Tracker
//:
require CAT_PATH.'/modules/BCStats/inc/Tracker.php';
if(!isset($stats)) $stats = false;
if(!isset($display)) $display = NULL;
$result = BCStats_Tracker::track($stats,$display);
if($result) {
    global $page_id;
    if(!CAT_Helper_Droplet::is_registered_droplet_css('cat_counter',$page_id)) {
        CAT_Helper_Droplet::register_droplet_css('cat_counter',$page_id,'BCStats','css/frontend.css');
    }
}
return $result;
